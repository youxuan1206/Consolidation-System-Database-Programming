﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class start
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(start))
        登入 = New Button()
        註冊 = New Button()
        PictureBox1 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' 登入
        ' 
        登入.BackgroundImage = CType(resources.GetObject("登入.BackgroundImage"), Image)
        登入.Location = New Point(52, 662)
        登入.Name = "登入"
        登入.Size = New Size(347, 59)
        登入.TabIndex = 0
        登入.UseVisualStyleBackColor = True
        ' 
        ' 註冊
        ' 
        註冊.BackColor = SystemColors.ActiveCaption
        註冊.BackgroundImage = CType(resources.GetObject("註冊.BackgroundImage"), Image)
        註冊.Location = New Point(52, 743)
        註冊.Name = "註冊"
        註冊.Size = New Size(347, 59)
        註冊.TabIndex = 1
        註冊.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(0, -3)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(453, 852)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' start
        ' 
        AutoScaleDimensions = New SizeF(11F, 23F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(452, 851)
        Controls.Add(註冊)
        Controls.Add(登入)
        Controls.Add(PictureBox1)
        Name = "start"
        StartPosition = FormStartPosition.CenterScreen
        Text = "start"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents 登入 As Button
    Friend WithEvents 註冊 As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
