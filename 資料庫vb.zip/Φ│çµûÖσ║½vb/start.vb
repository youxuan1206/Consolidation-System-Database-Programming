﻿Public Class start

    Private WithEvents Button1 As New Button()
    Private WithEvents Button2 As New Button()


    Private Sub 登入_Click(sender As Object, e As EventArgs) Handles 登入.Click
        Me.Hide()
        Dim 登入Form As New 登入()
        登入Form.ShowDialog()
    End Sub

    Private Sub 註冊_Click(sender As Object, e As EventArgs) Handles 註冊.Click
        Me.Hide()
        Dim 註冊Form As New 註冊()
        註冊Form.ShowDialog()
    End Sub

    Private Sub start_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.StartPosition = FormStartPosition.CenterScreen
    End Sub
End Class