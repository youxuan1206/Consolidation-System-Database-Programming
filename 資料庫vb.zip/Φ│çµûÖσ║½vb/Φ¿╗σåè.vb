﻿Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class 註冊

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        start.Show() ' 顯示初始介面的表單
        Me.Close() ' 關閉當前表單
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        '創建帳戶的Button
        Dim 顧客姓名 As String = TextBox1.Text
        Dim 手機號碼 As String = TextBox2.Text
        Dim 密碼 As String = TextBox3.Text
        Dim 確認密碼 As String = TextBox4.Text
        Dim 收貨地址 As String = TextBox5.Text
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub 註冊_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class