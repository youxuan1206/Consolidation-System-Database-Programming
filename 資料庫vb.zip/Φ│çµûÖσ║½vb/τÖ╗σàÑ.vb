﻿Public Class 登入
    '

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Dim random As New Random()
        Dim randomString As String = ""
        GenerateRandomString(randomString)
        Console.WriteLine(randomString)
    End Sub
    Public Sub GenerateRandomString(ByRef result As String)
        Dim random As New Random()

        ' 產生第一個字母（大寫英文字母）
        Dim firstLetter As Char = Chr(random.Next(65, 91)) ' ASCII碼範圍：65-90

        ' 產生後4位數字
        Dim numbers As String = random.Next(1000, 10000).ToString()

        ' 組合成最終的字串
        result = firstLetter & numbers
    End Sub

End Class